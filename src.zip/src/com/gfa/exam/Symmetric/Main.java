package com.gfa.exam.Symmetric;

//import static com.gfa.exam.Symmetric.SymmetricMatrix.isSymmetric;

public class Main {
    public static void main(String[] args) {
        int n = 3;
//        isSymmetric(n);
    }
}
