package com.gfa.exam.Pirate;

public class Main {
    public static void main(String[] args) {
        Pirate pirate = new Pirate("John");
        pirate.getGoldAmount();
        pirate.isPoor();
    }
}
